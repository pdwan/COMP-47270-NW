function CFsimple

Y = load('ml.dat');

p = randperm(length(Y));

Y(:,1) = Y(p,1);
Y(:,2) = Y(p,2);
Y(:,3) = Y(p,3);

% split into 5 sets

numTrans = length(Y);

first=1;
last=floor(numTrans/5);
sumAbsErr = 0;
totalTrans = 0;
for i=1:5,
    
    testY = Y(first:last,:);
    trainY = [Y(1:(first-1),:);Y((last+1):end,:)];
    
    first = first+last;
    last = last+last;

    trainSet = sparse(trainY(:,1),trainY(:,2),trainY(:,3));
    testSet = sparse(testY(:,1),testY(:,2),testY(:,3));
    
    
    for trans=1:length(testY),
        
        activeUser = testY(trans,1);
        activeItem = testY(trans,2);
        activeRating = testY(trans,3);
        
        sim = computeSimilarities(activeUser,trainSet);
        
        sim(activeUser)=-1;
        
        k = 20;
        
        mask = trainSet(:,activeItem)>0;
        sim(mask==0)=-1;
               
        [s,indx]=sort(sim,'descend');
        
        neighbours = indx(1:k);
        
        mask=sim(neighbours)>0;
        
        
        neighbours = neighbours(mask);
        
        if (length(neighbours)==0)
            predictRating = 3;
        else
        
         predictRating = round(mean(trainSet(neighbours,activeItem)));
        end
        
        
        
       sumAbsErr = sumAbsErr+abs(predictRating-activeRating); 
       totalTrans = totalTrans+1;
       
       if (mod(totalTrans,100)==0)
           
           fprintf('%e\n', sumAbsErr/totalTrans);
       end
               
        
    end
    
end

MAE = sumAbsErr/totalTrans;


function sim=computeSimilarities(user,trainSet)


user_row = trainSet(user,:);
sim = trainSet*user_row';


